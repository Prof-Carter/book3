for i = 1:3
  fprintf('i = %d\n', i);
end
fprintf('\n');
  
for j = -3:4:5
  for k = 2:-1:0
    fprintf('j = %d, k = %d\n', j, k);
  end
end