figure(1);
plot(t,x(:,1));
grid;
xlabel('time [s]');
ylabel('x1 [m]');

figure(2);
plot(t,x(:,2));
grid;
xlabel('t [s]');
ylabel('x2 [m/s]');

