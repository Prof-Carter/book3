plot(t,y); 
grid;
xlabel('t [s]');
ylabel('position (cart2) [m]');
