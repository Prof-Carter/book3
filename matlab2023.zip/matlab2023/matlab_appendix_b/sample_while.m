i = 1;
while i <= 3
  fprintf('i = %d\n', i);
  i = i + 1;
end