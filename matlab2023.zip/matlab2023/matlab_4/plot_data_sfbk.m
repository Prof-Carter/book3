figure(1);
plot(t,x(:,1)); grid;
xlabel('t [s]');
ylabel('x1 [V]');

figure(2);
plot(t,x(:,2)); grid;
xlabel('t [s]');
ylabel('x2 [V]');

