disp('++++++++++++++++++++++++++++++')
disp('�� 5.1�iSimulink �𗘗p�����V�~�����[�V�����j')
disp('++++++++++++++++++++++++++++++')

close all
clear
format compact

A = [ 0  1  0  0
     -4 -2  4  2
      0  0  0  1
      2  1 -2 -1 ];
b = [ 0
      2
      0
      0 ];
c = [ 0  0  1  0 ];

k = [ -7/2 -5/2 -13/2 -11/2];
h = 10;

tf = 5;
sim('eg_5_01_R2018a',tf)    % R2018a �ȍ~
% sim('eg_5_01_R2020a',tf)    % R2020a �ȍ~
% sim('eg_5_01_R2023a',tf)    % R2023a �ȍ~

figure(1)
plot(t,y,'LineWidth',1.5)
grid

xlim([0 5])
ylim([0 1.5])
set(gca,'XTick',[0:1:5])
set(gca,'YTick',[0:0.5:1.5])
set(gca,'FontName','Arial','FontSize',20)

xlabel('t [s]','FontName','Arial','FontSize',22)
ylabel('y(t) [m]','FontName','Arial','FontSize',22)


