plot(t,y);
grid;
xlabel('t [s]');
ylabel('y(t)');