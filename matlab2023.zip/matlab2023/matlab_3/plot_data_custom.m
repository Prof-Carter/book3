plot(t,y,'LineWidth',1.5);
grid;
xlabel('{\it{t}} [s]','FontName','Times New Roman','FontSize',22)
ylabel('{\it{y}}_{1}({\it{t}})','FontName','Times New Roman','FontSize',22)

set(gca,'FontName','Times New Roman','FontSize',20)
 
